//
//  ScrumdingerApp.swift
//  Scrumdinger
//
//  Created by Betty Godier on 22/03/2022.
//

import SwiftUI

@main
struct ScrumdingerApp: App {
    var body: some Scene {
        WindowGroup {
            MeetingView()
        }
    }
}
